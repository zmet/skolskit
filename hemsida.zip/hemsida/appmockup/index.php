

<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="css.css">
	</head>
<body>

<div class="header">
	BoStaden
</div>


<div class="form">
	<form id="login" action="nyheter.php">
		<label>Personnummer</label> <br />
		<input type="text" class="text" /> <br />
		<label>Lösenord</label> <br />
		<input type="password" class="text" /> <br />
		<input type="submit" class="button" value="Loggin"/>
	</form>
</div>

</body>
</html>