<h2>Stadsdelar</h2>
<div class="areas">
	<header>
		<h3>Centrum</h3>
	</header>
	<div class='left'>
		<h3>Bild</h3>
		<img src="areaimg/centrum.png" />
	</div>
	<div class='right'>
		<h3>Information</h3>
		<p>
			H�r kan man bo! N�ra till allt! Aff�rer och fris�rsallonger finns som vanligt 4st p� varje gata. Finns tillg�ng till vatten och frisk luft, f�rskolor och n�rliggande f�ngelse.
		</p>
	</div>
</div>
<div class="areas">
	<header>
		<h3>Parken</h3>
	</header>
	<div class='left'>
		<h3>Bild</h3>
		<img src="areaimg/parken.png" />
	</div>
	<div class='right'>
		<h3>Information</h3>
		<p>
			H�r kan man bo! N�ra till allt! Aff�rer och fris�rsallonger finns som vanligt 4st p� varje gata. Finns tillg�ng till vatten och frisk luft, f�rskolor och n�rliggande f�ngelse.
		</p>
	</div>
</div>
<div class="areas">
	<header>
		<h3>Kullen</h3>
	</header>
	<div class='left'>
		<h3>Bild</h3>
		<img src="areaimg/kullen.png" />
	</div>
	<div class='right'>
		<h3>Information</h3>
		<p>
			H�r kan man bo! N�ra till allt! Aff�rer och fris�rsallonger finns som vanligt 4st p� varje gata. Finns tillg�ng till vatten och frisk luft, f�rskolor och n�rliggande f�ngelse.
		</p>
	</div>
</div>
<div class="areas">
	<header>
		<h3>Svackan</h3>
	</header>
	<div class='left'>
		<h3>Bild</h3>
		<img src="areaimg/svackan.png" />
	</div>
	<div class='right'>
		<h3>Information</h3>
		<p>
			H�r kan man bo! N�ra till allt! Aff�rer och fris�rsallonger finns som vanligt 4st p� varje gata. Finns tillg�ng till vatten och frisk luft, f�rskolor och n�rliggande f�ngelse.
		</p>
	</div>
</div>
<div class="areas">
	<header>
		<h3>Bingen</h3>
	</header>
	<div class='left'>
		<h3>Bild</h3>
		<img src="areaimg/bingen.png" />
	</div>
	<div class='right'>
		<h3>Information</h3>
		<p>
			H�r kan man bo! N�ra till allt! Aff�rer och fris�rsallonger finns som vanligt 4st p� varje gata. Finns tillg�ng till vatten och frisk luft, f�rskolor och n�rliggande f�ngelse.
		</p>
	</div>
</div>