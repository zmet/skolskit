</div> <!-- .wrap ends here -->
<footer id="footer">
	<p>Copyright &copy; 2012</p>
</footer>
</body>
</html>