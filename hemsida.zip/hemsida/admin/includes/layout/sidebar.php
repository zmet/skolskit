<?php
	echo "<h2>L�nkar</h2>";
	echo "<a href='index.php?p=add'>L�gg till l�genhet</a><br />";
	echo "<a href='index.php?p=change'>�ndra p� l�genhet</a><br />";
	echo "<a href='index.php?p=adduser'>L�gg till admin</a><br />";
	echo "<a href='index.php?p=request'>Se ans�kningar</a><br />";
	echo "<a href='index.php?p=owners'>Hyres�gare</a><br />";
	echo "<a href='index.php?p=addnews'>L�gg till nyhet</a><br />";
	echo '<a href="includes/functions/logout.php">Logga ut</a>';
?>