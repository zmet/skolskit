<?php require_once('includes/functions/functions.php'); ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="ISO-8859-4">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title></title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="icon" type="image/png" href="favicon.png">
  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="apple-touch-icon-144-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="apple-touch-icon-114-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="apple-touch-icon-72-precomposed.png">
  <link rel="apple-touch-icon-precomposed" href="apple-touch-icon-57-precomposed.png">
  <link href='http://fonts.googleapis.com/css?family=Mouse+Memoirs' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header id="top">
	<div>
		<h1><a href="index.php">L�genheter - Administration</a></h1>
	</div>
</header>
<div class="wrap clearfix">