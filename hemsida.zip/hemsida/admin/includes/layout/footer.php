</div> <!-- .wrap ends here -->
<footer id="footer">
	<p>Copyright &copy; 2012</p>
	<p class='right'>
		<a target='_blank' href='https://www.fluidui.com/editor/live/preview/p_q7RPx7bX9DKF4PbPqGMLpqn4uPQfkpUh.1357686053415'>
			Android
		</a>
	</p>
</footer>
</body>
</html>