<?php

mysql_connect('193.17.218.162', '162226_zv99243', 'QtfMv#pZ') or die('database connection error');
mysql_select_db('162226-mm') or die('database connection error');

?>