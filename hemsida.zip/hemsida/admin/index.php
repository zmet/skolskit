<?php
require_once('includes/layout/header.php');
require_once('includes/layout/content.php');
require_once('includes/layout/footer.php');
?>